Los archivos .jar, .bat y .sh de cada proyecto, se encuentran en la siguiente ruta:
Proyecto/out/artifacts/Proyecto_jar