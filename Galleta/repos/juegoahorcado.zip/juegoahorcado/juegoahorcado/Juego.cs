﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace juegoahorcado
{
    public partial class formJuego : Form
    {
        public formJuego()
        {
            InitializeComponent();
            IniciarValores();
            palabraRandom();
            pbImagen2.Visible = false;
            pbImagen3.Visible = false;
            pbImagen4.Visible = false;
            pbImagen5.Visible = false;
            pbImagen6.Visible = false;
            pbImagen7.Visible = false;
            pbImagen8.Visible = false;

            foreach (Button x in flBotonera.Controls.OfType<Button>())
            {
                x.Click += comprobarLetra;
            }
        }

        char[] abecedario;
        String aux = "";
        int errores = 0;
        int puntuacion;

        public void IniciarValores()
        {
            abecedario = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ-".ToCharArray();
            foreach (char letraAbecedario in abecedario)
            {
                Button btnLetra = new Button();
                btnLetra.Tag = "";
                btnLetra.Text = letraAbecedario.ToString();
                btnLetra.Width = 70;
                btnLetra.Height = 70;
                btnLetra.ForeColor = Color.Black;
                btnLetra.Font = new Font(btnLetra.Font.Name, 15, FontStyle.Bold);
                btnLetra.BackColor = Color.White;
                btnLetra.Name = letraAbecedario.ToString();
                flBotonera.Controls.Add(btnLetra);
            }
        }



        private void comprobarLetra(Object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            Boolean win = false;
            string strin = "";

            for (int x = 0; x < aux.Length; x++)
            {
                if (boton.Text.Equals(aux[x].ToString()))
                {
                    char[] c = lbPalabraGuiones.Text.ToCharArray();
                    c[x] = char.Parse(boton.Text);

                    strin = new string(c);
                    lbPalabraGuiones.Text = strin;
                    win = true;
                    boton.Enabled = false;
                }
                else
                {
                    boton.Enabled = false;
                }
            }

            if (aux.Equals(strin))
            {
                puntuacion += 20;
                lbPuntos.Text = puntuacion.ToString();

                formMenu menuu = new formMenu();
                menuu.Show();
                menuu.lbPuntosFL.Text = puntuacion.ToString();
                formFin fin = new formFin();
                lbPalabraGuiones.Text = aux;
                fin.lbPalabra.Text = aux;
                fin.lbTitulo.Text = "Has ganado";
                this.Dispose();
                fin.ShowDialog();
                if (fin.btRegistrar.DialogResult == DialogResult.OK)
                {
                    menuu.lbNombreFL.Text = fin.txtNombre.Text;
                    menuu.lbAbreviaturaFL.Text = fin.txtAbreviatura.Text;
                    menuu.lbPartidaFL.Text = "Partida " + formMenu.partida;
                    formMenu.partida++;
                }

            }

            if (win == false)
            {
                errores++;

                switch (errores)
                {
                    case 1:
                        {
                            pbImagen.Visible = false;
                            pbImagen2.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }

                            break;
                        }

                    case 2:
                        {
                            pbImagen2.Visible = false;
                            pbImagen3.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }
                            break;
                        }

                    case 3:
                        {
                            pbImagen3.Visible = false;
                            pbImagen4.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }
                            break;
                        }

                    case 4:
                        {
                            pbImagen4.Visible = false;
                            pbImagen5.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }
                            break;
                        }

                    case 5:
                        {
                            pbImagen5.Visible = false;
                            pbImagen6.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }
                            break;
                        }

                    case 6:
                        {
                            pbImagen6.Visible = false;
                            pbImagen7.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }
                            break;
                        }

                    case 7:
                        {
                            pbImagen7.Visible = false;
                            pbImagen8.Visible = true;
                            puntuacion += -2;
                            lbPuntos.Text = puntuacion.ToString();

                            if (puntuacion < 0)
                            {
                                puntuacion = 0;
                                lbPuntos.Text = puntuacion.ToString();
                            }

                            flBotonera.Enabled = false;
                            formMenu menuu = new formMenu();
                            menuu.Show();
                            menuu.lbPuntosFL.Text = puntuacion.ToString();
                            formFin fin = new formFin();
                            lbPalabraGuiones.Text = aux;
                            fin.lbPalabra.Text = aux;
                            this.Dispose();
                            fin.ShowDialog();
                            if (fin.btRegistrar.DialogResult == DialogResult.OK)
                            {
                                menuu.lbNombreFL.Text = fin.txtNombre.Text;
                                menuu.lbAbreviaturaFL.Text = fin.txtAbreviatura.Text;
                                menuu.lbPartidaFL.Text = "Partida " + formMenu.partida;
                                formMenu.partida++;
                            }

                            break;
                        }

                }
            }
            else
            {
                puntuacion += 5;
                lbPuntos.Text = puntuacion.ToString();
            }
        }
        private void palabraRandom()
        {
            Random random = new Random();
            int rand = random.Next(0, 3);


            if (formMenu.comboCategoria.SelectedItem.Equals("Deportes") && formMenu.comboDificultad.SelectedItem.Equals("Facil"))
            {
                aux = formMenu.DeportesFacil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Deportes") && formMenu.comboDificultad.SelectedItem.Equals("Normal"))
            {
                aux = formMenu.DeportesNormal[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Deportes") && formMenu.comboDificultad.SelectedItem.Equals("Dificil"))
            {
                aux = formMenu.DeportesDificil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Telefonos") && formMenu.comboDificultad.SelectedItem.Equals("Facil"))
            {
                aux = formMenu.TelefonosFacil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Telefonos") && formMenu.comboDificultad.SelectedItem.Equals("Normal"))
            {
                aux = formMenu.TelefonosNormal[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Telefonos") && formMenu.comboDificultad.SelectedItem.Equals("Dificil"))
            {
                aux = formMenu.TelefonosDificil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Monedas") && formMenu.comboDificultad.SelectedItem.Equals("Facil"))
            {
                aux = formMenu.MonedasFacil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Monedas") && formMenu.comboDificultad.SelectedItem.Equals("Normal"))
            {
                aux = formMenu.MonedasNormal[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Monedas") && formMenu.comboDificultad.SelectedItem.Equals("Dificil"))
            {
                aux = formMenu.MonedasDificil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Localidades") && formMenu.comboDificultad.SelectedItem.Equals("Facil"))
            {
                aux = formMenu.LocalidadesFacil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Localidades") && formMenu.comboDificultad.SelectedItem.Equals("Normal"))
            {
                aux = formMenu.LocalidadesNormal[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
            if (formMenu.comboCategoria.SelectedItem.Equals("Localidades") && formMenu.comboDificultad.SelectedItem.Equals("Dificil"))
            {
                aux = formMenu.LocalidadesDificil[rand].ToUpper();
                for (int i = 0; i < aux.Length; i++)
                {
                    lbPalabraGuiones.Text += "_";
                }
            }
        }
    }

}