﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace juegoahorcado
{
    public partial class formFin : Form
    {
        public formFin()
        {
            InitializeComponent();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {

        }

        private void btRegistrar_Click(object sender, EventArgs e)
        {

        }
    }
}
