namespace juegoahorcado
{
    using System.IO;
    public partial class formMenu : Form
    {

        public formMenu()
        {
            InitializeComponent();
            DatosListasDeportes();
            DatosListasTelefonos();
            DatosListasMonedas();
            DatosListasLocalidades();
        }

        public static int partida = 1;

        //Creacion de las listas
        public static List<String> DeportesFacil = new List<String>();
        public static List<String> DeportesNormal = new List<String>();
        public static List<String> DeportesDificil = new List<String>();

        public static List<String> TelefonosFacil = new List<String>();
        public static List<String> TelefonosNormal = new List<String>();
        public static List<String> TelefonosDificil = new List<String>();

        public static List<String> MonedasFacil = new List<String>();
        public static List<String> MonedasNormal = new List<String>();
        public static List<String> MonedasDificil = new List<String>();

        public static List<String> LocalidadesFacil = new List<String>();
        public static List<String> LocalidadesNormal = new List<String>();
        public static List<String> LocalidadesDificil = new List<String>();


        //Introduccion de datos de las listas
        public void DatosListasDeportes()
        {
            //Deportes Facil
            DeportesFacil.Add("Futbol");
            DeportesFacil.Add("Tenis");
            DeportesFacil.Add("Padel");
            DeportesFacil.Add("Golf");

            //Deportes Normal
            DeportesNormal.Add("Baloncesto");
            DeportesNormal.Add("Natacion");
            DeportesNormal.Add("Voleibol");
            DeportesNormal.Add("Ciclismo");

            //Deportes Dificil
            DeportesDificil.Add("Kayak-Polo");
            DeportesDificil.Add("Patinaje-Artistico");
            DeportesDificil.Add("Natacion-Sincronizada");
            DeportesDificil.Add("Gimnasia-Ritmica");
        }

        public void DatosListasTelefonos()
        {
            //Telefonos Facil
            TelefonosFacil.Add("LG");
            TelefonosFacil.Add("Xiaomi");
            TelefonosFacil.Add("Samsung");
            TelefonosFacil.Add("Nokia");

            //Telefonos Normal
            TelefonosNormal.Add("Nothing-Phone");
            TelefonosNormal.Add("Iphone");
            TelefonosNormal.Add("Huawei");
            TelefonosNormal.Add("OnePlus");

            //Telefonos Dificil
            TelefonosDificil.Add("Samsung-Galaxy");
            TelefonosDificil.Add("Xiaomi-Redmi");
            TelefonosDificil.Add("Oppo-Find");
            TelefonosDificil.Add("Redmagic-Mars");
        }

        public void DatosListasMonedas()
        {
            //Monedas Facil
            MonedasFacil.Add("Euro");
            MonedasFacil.Add("Dolar");
            MonedasFacil.Add("Peso");
            MonedasFacil.Add("Libra");

            //Monedas Normal
            MonedasNormal.Add("Rublo");
            MonedasNormal.Add("Yuan");
            MonedasNormal.Add("Lira");
            MonedasNormal.Add("Franco");

            //Monedas Dificil
            MonedasDificil.Add("Real-Brasile�o");
            MonedasDificil.Add("Rupia-India");
            MonedasDificil.Add("Bath-Tailandes");
            MonedasDificil.Add("Won-Surcoreano");
        }

        public void DatosListasLocalidades()
        {
            //Localidades Facil
            LocalidadesFacil.Add("Huelva");
            LocalidadesFacil.Add("Sevilla");
            LocalidadesFacil.Add("Malaga");
            LocalidadesFacil.Add("Cadiz");

            //Localidades Normal
            LocalidadesNormal.Add("Almonte");
            LocalidadesNormal.Add("Dos-Hermanas");
            LocalidadesNormal.Add("Marbella");
            LocalidadesNormal.Add("Algeciras");

            //Localidades Dificil
            LocalidadesDificil.Add("Aljaraque");
            LocalidadesDificil.Add("Constantina");
            LocalidadesDificil.Add("Torremolinos");
            LocalidadesDificil.Add("San Fernando");
        }

        //Boton de salida de la pantalla
        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.Exit();
        }


        //Boton para comenzar el juego
        private void btJugar_Click(object sender, EventArgs e)
        {

            if (comboCategoria.SelectedItem != null || comboDificultad.SelectedItem != null)
            {

                if (comboDificultad.SelectedItem != null && comboCategoria.SelectedItem.Equals("Deportes"))
                {
                    formJuego deporte = new formJuego();
                    deporte.lbTituloJuego.Text = "DEPORTES";
                    deporte.Show();


                }
                else if (comboDificultad.SelectedItem != null && comboCategoria.SelectedItem.Equals("Telefonos"))
                {
                    formJuego telefonos = new formJuego();
                    telefonos.lbTituloJuego.Text = "TELEFONOS";
                    telefonos.Show();

                }
                else if (comboDificultad.SelectedItem != null && comboCategoria.SelectedItem.Equals("Monedas"))
                {
                    formJuego monedas = new formJuego();
                    monedas.lbTituloJuego.Text = "MONEDAS";
                    monedas.Show();

                }
                else if (comboDificultad.SelectedItem != null && comboCategoria.SelectedItem.Equals("Localidades"))
                {
                    formJuego Localidades = new formJuego();
                    Localidades.lbTituloJuego.Text = "LOCALIDADES";
                    Localidades.Show();

                }
                else
                {
                    MessageBox.Show("Rellena las opciones para jugar");
                }
            }
            else
            {
                MessageBox.Show("Rellena las opciones para jugar");
            }
        }
    }
}