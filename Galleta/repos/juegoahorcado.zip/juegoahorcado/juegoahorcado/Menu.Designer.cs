﻿namespace juegoahorcado
{
    partial class formMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btSalir = new Button();
            label1 = new Label();
            comboCategoria = new ComboBox();
            lbCategoria = new Label();
            lbDificultad = new Label();
            comboDificultad = new ComboBox();
            btJugar = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            groupInstrucciones = new GroupBox();
            lb3Instruccion = new Label();
            lb2Instruccion = new Label();
            lb1Instruccion = new Label();
            panel3 = new Panel();
            pbImagenMenu = new PictureBox();
            flPuntuaciones = new FlowLayoutPanel();
            lbFlNombre = new Label();
            lbFlAbrv = new Label();
            lbFlPartida = new Label();
            lbFlPuntos = new Label();
            lbNombreFL = new Label();
            lbAbreviaturaFL = new Label();
            lbPartidaFL = new Label();
            lbPuntosFL = new Label();
            lbTituloLeaderboard = new Label();
            panel4 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            groupInstrucciones.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbImagenMenu).BeginInit();
            flPuntuaciones.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // btSalir
            // 
            btSalir.AccessibleRole = AccessibleRole.Animation;
            btSalir.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btSalir.BackColor = Color.Transparent;
            btSalir.BackgroundImageLayout = ImageLayout.None;
            btSalir.Cursor = Cursors.Hand;
            btSalir.FlatAppearance.BorderSize = 0;
            btSalir.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btSalir.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 128, 128);
            btSalir.FlatStyle = FlatStyle.Flat;
            btSalir.Font = new Font("Wide Latin", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btSalir.ForeColor = Color.Transparent;
            btSalir.Location = new Point(1250, 0);
            btSalir.Name = "btSalir";
            btSalir.Size = new Size(50, 33);
            btSalir.TabIndex = 0;
            btSalir.Text = "X";
            btSalir.UseVisualStyleBackColor = false;
            btSalir.Click += btSalir_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Wide Latin", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(7, 6);
            label1.Name = "label1";
            label1.Size = new Size(401, 33);
            label1.TabIndex = 1;
            label1.Text = "EL AHORCADO";
            // 
            // comboCategoria
            // 
            comboCategoria.Items.AddRange(new object[] { "Deportes", "Telefonos", "Monedas", "Localidades" });
            comboCategoria.Location = new Point(316, 17);
            comboCategoria.Name = "comboCategoria";
            comboCategoria.Size = new Size(121, 28);
            comboCategoria.TabIndex = 9;
            // 
            // lbCategoria
            // 
            lbCategoria.AutoSize = true;
            lbCategoria.BackColor = Color.Transparent;
            lbCategoria.Font = new Font("Wide Latin", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lbCategoria.ForeColor = Color.White;
            lbCategoria.Location = new Point(7, 10);
            lbCategoria.Name = "lbCategoria";
            lbCategoria.Size = new Size(262, 37);
            lbCategoria.TabIndex = 3;
            lbCategoria.Text = "Categoría";
            // 
            // lbDificultad
            // 
            lbDificultad.AutoSize = true;
            lbDificultad.BackColor = Color.Transparent;
            lbDificultad.Font = new Font("Wide Latin", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lbDificultad.ForeColor = Color.White;
            lbDificultad.Location = new Point(7, 62);
            lbDificultad.Name = "lbDificultad";
            lbDificultad.Size = new Size(274, 37);
            lbDificultad.TabIndex = 5;
            lbDificultad.Text = "Dificultad";
            // 
            // comboDificultad
            // 
            comboDificultad.ItemHeight = 20;
            comboDificultad.Items.AddRange(new object[] { "Facil", "Normal", "Dificil" });
            comboDificultad.Location = new Point(316, 68);
            comboDificultad.Name = "comboDificultad";
            comboDificultad.Size = new Size(121, 28);
            comboDificultad.TabIndex = 8;
            // 
            // btJugar
            // 
            btJugar.AccessibleRole = AccessibleRole.Animation;
            btJugar.Anchor = AnchorStyles.Bottom;
            btJugar.BackColor = Color.Transparent;
            btJugar.BackgroundImageLayout = ImageLayout.None;
            btJugar.Cursor = Cursors.Hand;
            btJugar.FlatAppearance.BorderSize = 0;
            btJugar.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btJugar.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 128, 128);
            btJugar.FlatStyle = FlatStyle.Flat;
            btJugar.Font = new Font("Wide Latin", 16F, FontStyle.Bold, GraphicsUnit.Point);
            btJugar.ForeColor = Color.Transparent;
            btJugar.Location = new Point(137, 600);
            btJugar.Name = "btJugar";
            btJugar.Size = new Size(214, 35);
            btJugar.TabIndex = 6;
            btJugar.Text = "JUGAR";
            btJugar.UseVisualStyleBackColor = false;
            btJugar.Click += btJugar_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btSalir);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1300, 75);
            panel1.TabIndex = 10;
            // 
            // panel2
            // 
            panel2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel2.BackColor = Color.Transparent;
            panel2.Controls.Add(panel4);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 75);
            panel2.Name = "panel2";
            panel2.Size = new Size(461, 645);
            panel2.TabIndex = 11;
            // 
            // groupInstrucciones
            // 
            groupInstrucciones.Controls.Add(lb3Instruccion);
            groupInstrucciones.Controls.Add(lb2Instruccion);
            groupInstrucciones.Controls.Add(lb1Instruccion);
            groupInstrucciones.Font = new Font("Wide Latin", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupInstrucciones.Location = new Point(7, 115);
            groupInstrucciones.Name = "groupInstrucciones";
            groupInstrucciones.Size = new Size(430, 118);
            groupInstrucciones.TabIndex = 10;
            groupInstrucciones.TabStop = false;
            groupInstrucciones.Text = "Instrucciones";
            // 
            // lb3Instruccion
            // 
            lb3Instruccion.Anchor = AnchorStyles.Left;
            lb3Instruccion.AutoSize = true;
            lb3Instruccion.Font = new Font("Wide Latin", 8F, FontStyle.Regular, GraphicsUnit.Point);
            lb3Instruccion.Location = new Point(0, 97);
            lb3Instruccion.Name = "lb3Instruccion";
            lb3Instruccion.Size = new Size(425, 18);
            lb3Instruccion.TabIndex = 2;
            lb3Instruccion.Text = "3º Intente adivinar la palabra oculta";
            lb3Instruccion.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb2Instruccion
            // 
            lb2Instruccion.Anchor = AnchorStyles.Left;
            lb2Instruccion.AutoSize = true;
            lb2Instruccion.Font = new Font("Wide Latin", 8F, FontStyle.Regular, GraphicsUnit.Point);
            lb2Instruccion.Location = new Point(0, 69);
            lb2Instruccion.Name = "lb2Instruccion";
            lb2Instruccion.Size = new Size(423, 18);
            lb2Instruccion.TabIndex = 1;
            lb2Instruccion.Text = "2º Pulse \"Jugar\" para iniciar el juego";
            lb2Instruccion.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb1Instruccion
            // 
            lb1Instruccion.Anchor = AnchorStyles.Left;
            lb1Instruccion.AutoSize = true;
            lb1Instruccion.Font = new Font("Wide Latin", 8F, FontStyle.Regular, GraphicsUnit.Point);
            lb1Instruccion.Location = new Point(0, 39);
            lb1Instruccion.Name = "lb1Instruccion";
            lb1Instruccion.Size = new Size(408, 18);
            lb1Instruccion.TabIndex = 0;
            lb1Instruccion.Text = "1º Seleccione categoría y dificultad";
            lb1Instruccion.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel3.BackColor = Color.Transparent;
            panel3.Controls.Add(pbImagenMenu);
            panel3.Controls.Add(flPuntuaciones);
            panel3.Controls.Add(lbTituloLeaderboard);
            panel3.Controls.Add(btJugar);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(461, 75);
            panel3.Name = "panel3";
            panel3.Size = new Size(839, 645);
            panel3.TabIndex = 13;
            // 
            // pbImagenMenu
            // 
            pbImagenMenu.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            pbImagenMenu.BackColor = Color.Transparent;
            pbImagenMenu.Image = Properties.Resources.ahorc0vx;
            pbImagenMenu.Location = new Point(71, 211);
            pbImagenMenu.Name = "pbImagenMenu";
            pbImagenMenu.Size = new Size(343, 341);
            pbImagenMenu.SizeMode = PictureBoxSizeMode.Zoom;
            pbImagenMenu.TabIndex = 14;
            pbImagenMenu.TabStop = false;
            // 
            // flPuntuaciones
            // 
            flPuntuaciones.Controls.Add(lbFlNombre);
            flPuntuaciones.Controls.Add(lbFlAbrv);
            flPuntuaciones.Controls.Add(lbFlPartida);
            flPuntuaciones.Controls.Add(lbFlPuntos);
            flPuntuaciones.Controls.Add(lbNombreFL);
            flPuntuaciones.Controls.Add(lbAbreviaturaFL);
            flPuntuaciones.Controls.Add(lbPartidaFL);
            flPuntuaciones.Controls.Add(lbPuntosFL);
            flPuntuaciones.Location = new Point(71, 86);
            flPuntuaciones.Name = "flPuntuaciones";
            flPuntuaciones.Size = new Size(343, 95);
            flPuntuaciones.TabIndex = 11;
            // 
            // lbFlNombre
            // 
            lbFlNombre.AutoSize = true;
            lbFlNombre.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbFlNombre.Location = new Point(3, 0);
            lbFlNombre.Name = "lbFlNombre";
            lbFlNombre.Size = new Size(76, 23);
            lbFlNombre.TabIndex = 0;
            lbFlNombre.Text = "Nombre";
            // 
            // lbFlAbrv
            // 
            lbFlAbrv.AutoSize = true;
            lbFlAbrv.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbFlAbrv.Location = new Point(85, 0);
            lbFlAbrv.Name = "lbFlAbrv";
            lbFlAbrv.Size = new Size(105, 23);
            lbFlAbrv.TabIndex = 1;
            lbFlAbrv.Text = "Abreviatura";
            // 
            // lbFlPartida
            // 
            lbFlPartida.AutoSize = true;
            lbFlPartida.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbFlPartida.Location = new Point(196, 0);
            lbFlPartida.Name = "lbFlPartida";
            lbFlPartida.Size = new Size(68, 23);
            lbFlPartida.TabIndex = 2;
            lbFlPartida.Text = "Partida";
            // 
            // lbFlPuntos
            // 
            lbFlPuntos.AutoSize = true;
            lbFlPuntos.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbFlPuntos.Location = new Point(270, 0);
            lbFlPuntos.Name = "lbFlPuntos";
            lbFlPuntos.Size = new Size(64, 23);
            lbFlPuntos.TabIndex = 3;
            lbFlPuntos.Text = "Puntos";
            // 
            // lbNombreFL
            // 
            lbNombreFL.AutoSize = true;
            lbNombreFL.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbNombreFL.Location = new Point(3, 23);
            lbNombreFL.Name = "lbNombreFL";
            lbNombreFL.Size = new Size(17, 23);
            lbNombreFL.TabIndex = 4;
            lbNombreFL.Text = "-";
            // 
            // lbAbreviaturaFL
            // 
            lbAbreviaturaFL.AutoSize = true;
            lbAbreviaturaFL.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbAbreviaturaFL.Location = new Point(26, 23);
            lbAbreviaturaFL.Name = "lbAbreviaturaFL";
            lbAbreviaturaFL.Size = new Size(17, 23);
            lbAbreviaturaFL.TabIndex = 5;
            lbAbreviaturaFL.Text = "-";
            // 
            // lbPartidaFL
            // 
            lbPartidaFL.AutoSize = true;
            lbPartidaFL.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbPartidaFL.Location = new Point(49, 23);
            lbPartidaFL.Name = "lbPartidaFL";
            lbPartidaFL.Size = new Size(17, 23);
            lbPartidaFL.TabIndex = 6;
            lbPartidaFL.Text = "-";
            // 
            // lbPuntosFL
            // 
            lbPuntosFL.AutoSize = true;
            lbPuntosFL.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lbPuntosFL.Location = new Point(72, 23);
            lbPuntosFL.Name = "lbPuntosFL";
            lbPuntosFL.Size = new Size(17, 23);
            lbPuntosFL.TabIndex = 7;
            lbPuntosFL.Text = "-";
            // 
            // lbTituloLeaderboard
            // 
            lbTituloLeaderboard.AutoSize = true;
            lbTituloLeaderboard.BackColor = Color.Transparent;
            lbTituloLeaderboard.Font = new Font("Wide Latin", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lbTituloLeaderboard.ForeColor = Color.White;
            lbTituloLeaderboard.Location = new Point(61, 19);
            lbTituloLeaderboard.Name = "lbTituloLeaderboard";
            lbTituloLeaderboard.Size = new Size(368, 37);
            lbTituloLeaderboard.TabIndex = 10;
            lbTituloLeaderboard.Text = "Puntuaciones";
            // 
            // panel4
            // 
            panel4.Controls.Add(groupInstrucciones);
            panel4.Controls.Add(comboDificultad);
            panel4.Controls.Add(lbDificultad);
            panel4.Controls.Add(lbCategoria);
            panel4.Controls.Add(comboCategoria);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(461, 284);
            panel4.TabIndex = 11;
            // 
            // formMenu
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.istockphoto_972936924_612x612;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1300, 720);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            MinimumSize = new Size(1300, 720);
            Name = "formMenu";
            Text = "Ahorcado";
            WindowState = FormWindowState.Maximized;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            groupInstrucciones.ResumeLayout(false);
            groupInstrucciones.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbImagenMenu).EndInit();
            flPuntuaciones.ResumeLayout(false);
            flPuntuaciones.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        public Button btSalir;
        public Label label1;
        public Label lbCategoria;
        public Label lbDificultad;
        public Button btJugar;
        public Panel panel1;
        public Panel panel2;
        public Panel panel3;
        public Label lbTituloLeaderboard;
        public GroupBox groupInstrucciones;
        public Label lb2Instruccion;
        public Label lb1Instruccion;
        public Label lb3Instruccion;
        public PictureBox pbImagenMenu;
        public FlowLayoutPanel flPuntuaciones;
        public Label lbFlNombre;
        public Label lbFlAbrv;
        public Label lbFlPartida;
        public Label lbFlPuntos;
        public Label lbNombreFL;
        public Label lbAbreviaturaFL;
        public Label lbPartidaFL;
        public Label lbPuntosFL;
        private Panel panel4;
        public static ComboBox comboCategoria;
        public static ComboBox comboDificultad;
    }
}