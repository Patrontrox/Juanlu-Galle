﻿namespace juegoahorcado
{
    partial class formFin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btRegistrar = new Button();
            lbNombre = new Label();
            lbAbreviatura = new Label();
            txtAbreviatura = new TextBox();
            txtNombre = new TextBox();
            groupJugador = new GroupBox();
            lbTitulo = new Label();
            label1 = new Label();
            lbPalabra = new Label();
            groupJugador.SuspendLayout();
            SuspendLayout();
            // 
            // btRegistrar
            // 
            btRegistrar.AccessibleRole = AccessibleRole.Animation;
            btRegistrar.Anchor = AnchorStyles.None;
            btRegistrar.BackColor = Color.PeachPuff;
            btRegistrar.BackgroundImageLayout = ImageLayout.None;
            btRegistrar.Cursor = Cursors.Hand;
            btRegistrar.DialogResult = DialogResult.OK;
            btRegistrar.FlatAppearance.BorderSize = 0;
            btRegistrar.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btRegistrar.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 192);
            btRegistrar.FlatStyle = FlatStyle.Flat;
            btRegistrar.Font = new Font("Wide Latin", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btRegistrar.ForeColor = Color.Black;
            btRegistrar.Location = new Point(523, 421);
            btRegistrar.Name = "btRegistrar";
            btRegistrar.Size = new Size(271, 55);
            btRegistrar.TabIndex = 17;
            btRegistrar.Text = "REGISTRAR";
            btRegistrar.UseVisualStyleBackColor = false;
            btRegistrar.Click += btRegistrar_Click;
            // 
            // lbNombre
            // 
            lbNombre.Anchor = AnchorStyles.Left;
            lbNombre.AutoSize = true;
            lbNombre.Font = new Font("Wide Latin", 8F, FontStyle.Regular, GraphicsUnit.Point);
            lbNombre.Location = new Point(0, 48);
            lbNombre.Name = "lbNombre";
            lbNombre.Size = new Size(104, 18);
            lbNombre.TabIndex = 0;
            lbNombre.Text = "Nombre";
            lbNombre.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbAbreviatura
            // 
            lbAbreviatura.Anchor = AnchorStyles.Left;
            lbAbreviatura.AutoSize = true;
            lbAbreviatura.Font = new Font("Wide Latin", 8F, FontStyle.Regular, GraphicsUnit.Point);
            lbAbreviatura.Location = new Point(0, 86);
            lbAbreviatura.Name = "lbAbreviatura";
            lbAbreviatura.Size = new Size(154, 18);
            lbAbreviatura.TabIndex = 1;
            lbAbreviatura.Text = "Abreviatura";
            lbAbreviatura.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtAbreviatura
            // 
            txtAbreviatura.Location = new Point(183, 69);
            txtAbreviatura.Name = "txtAbreviatura";
            txtAbreviatura.Size = new Size(125, 32);
            txtAbreviatura.TabIndex = 4;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(183, 32);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(125, 32);
            txtNombre.TabIndex = 5;
            // 
            // groupJugador
            // 
            groupJugador.Anchor = AnchorStyles.None;
            groupJugador.BackColor = Color.PeachPuff;
            groupJugador.Controls.Add(txtNombre);
            groupJugador.Controls.Add(txtAbreviatura);
            groupJugador.Controls.Add(lbAbreviatura);
            groupJugador.Controls.Add(lbNombre);
            groupJugador.Font = new Font("Wide Latin", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupJugador.Location = new Point(486, 290);
            groupJugador.Name = "groupJugador";
            groupJugador.Size = new Size(335, 115);
            groupJugador.TabIndex = 16;
            groupJugador.TabStop = false;
            groupJugador.Text = "Registro";
            // 
            // lbTitulo
            // 
            lbTitulo.Anchor = AnchorStyles.None;
            lbTitulo.AutoSize = true;
            lbTitulo.BackColor = Color.PeachPuff;
            lbTitulo.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lbTitulo.Location = new Point(556, 130);
            lbTitulo.Name = "lbTitulo";
            lbTitulo.Size = new Size(190, 41);
            lbTitulo.TabIndex = 18;
            lbTitulo.Text = "Has perdido";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.PeachPuff;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(544, 182);
            label1.Name = "label1";
            label1.Size = new Size(216, 41);
            label1.TabIndex = 19;
            label1.Text = "La palabra era";
            // 
            // lbPalabra
            // 
            lbPalabra.Anchor = AnchorStyles.None;
            lbPalabra.AutoSize = true;
            lbPalabra.BackColor = Color.PeachPuff;
            lbPalabra.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lbPalabra.Location = new Point(589, 236);
            lbPalabra.Name = "lbPalabra";
            lbPalabra.Size = new Size(123, 41);
            lbPalabra.TabIndex = 20;
            lbPalabra.Text = "Palabra";
            // 
            // formFin
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackgroundImage = Properties.Resources.istockphoto_972936924_612x612;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1328, 850);
            Controls.Add(lbPalabra);
            Controls.Add(label1);
            Controls.Add(lbTitulo);
            Controls.Add(btRegistrar);
            Controls.Add(groupJugador);
            FormBorderStyle = FormBorderStyle.None;
            MinimumSize = new Size(1300, 720);
            Name = "formFin";
            Text = "Fin";
            WindowState = FormWindowState.Maximized;
            groupJugador.ResumeLayout(false);
            groupJugador.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public Button btRegistrar;
        public Label lbNombre;
        public Label lbAbreviatura;
        public TextBox txtAbreviatura;
        public TextBox txtNombre;
        public GroupBox groupJugador;
        public Label lbTitulo;
        public Label label1;
        public Label lbPalabra;
    }
}