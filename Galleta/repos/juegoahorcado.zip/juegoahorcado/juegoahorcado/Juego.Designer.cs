﻿namespace juegoahorcado
{
    partial class formJuego
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbTituloJuego = new Label();
            flBotonera = new FlowLayoutPanel();
            lbPalabraGuiones = new Label();
            lbPuntos = new Label();
            pbImagen = new PictureBox();
            pbImagen2 = new PictureBox();
            pbImagen3 = new PictureBox();
            pbImagen4 = new PictureBox();
            pbImagen5 = new PictureBox();
            pbImagen6 = new PictureBox();
            pbImagen7 = new PictureBox();
            pbImagen8 = new PictureBox();
            lbPuntuacionTexto = new Label();
            ((System.ComponentModel.ISupportInitialize)pbImagen).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen8).BeginInit();
            SuspendLayout();
            // 
            // lbTituloJuego
            // 
            lbTituloJuego.AutoSize = true;
            lbTituloJuego.BackColor = Color.Transparent;
            lbTituloJuego.Font = new Font("Wide Latin", 16F, FontStyle.Regular, GraphicsUnit.Point);
            lbTituloJuego.ForeColor = Color.White;
            lbTituloJuego.Location = new Point(3, 3);
            lbTituloJuego.Name = "lbTituloJuego";
            lbTituloJuego.Size = new Size(276, 33);
            lbTituloJuego.TabIndex = 2;
            lbTituloJuego.Text = "DEPORTE";
            // 
            // flBotonera
            // 
            flBotonera.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            flBotonera.BackColor = Color.Transparent;
            flBotonera.Location = new Point(471, 436);
            flBotonera.Name = "flBotonera";
            flBotonera.Size = new Size(799, 225);
            flBotonera.TabIndex = 5;
            // 
            // lbPalabraGuiones
            // 
            lbPalabraGuiones.Anchor = AnchorStyles.Bottom;
            lbPalabraGuiones.AutoSize = true;
            lbPalabraGuiones.BackColor = Color.Transparent;
            lbPalabraGuiones.Font = new Font("Algerian", 36F, FontStyle.Bold, GraphicsUnit.Point);
            lbPalabraGuiones.Location = new Point(857, 324);
            lbPalabraGuiones.Name = "lbPalabraGuiones";
            lbPalabraGuiones.Size = new Size(0, 66);
            lbPalabraGuiones.TabIndex = 11;
            lbPalabraGuiones.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbPuntos
            // 
            lbPuntos.AutoSize = true;
            lbPuntos.BackColor = Color.Transparent;
            lbPuntos.Font = new Font("Wide Latin", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lbPuntos.Location = new Point(273, 34);
            lbPuntos.Name = "lbPuntos";
            lbPuntos.Size = new Size(0, 42);
            lbPuntos.TabIndex = 13;
            // 
            // pbImagen
            // 
            pbImagen.Image = Properties.Resources.ahorcado1;
            pbImagen.Location = new Point(12, 81);
            pbImagen.Name = "pbImagen";
            pbImagen.Size = new Size(453, 581);
            pbImagen.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen.TabIndex = 14;
            pbImagen.TabStop = false;
            // 
            // pbImagen2
            // 
            pbImagen2.Image = Properties.Resources.ahorcado2;
            pbImagen2.Location = new Point(12, 81);
            pbImagen2.Name = "pbImagen2";
            pbImagen2.Size = new Size(453, 581);
            pbImagen2.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen2.TabIndex = 15;
            pbImagen2.TabStop = false;
            // 
            // pbImagen3
            // 
            pbImagen3.Image = Properties.Resources.ahorcado3;
            pbImagen3.Location = new Point(12, 81);
            pbImagen3.Name = "pbImagen3";
            pbImagen3.Size = new Size(453, 581);
            pbImagen3.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen3.TabIndex = 16;
            pbImagen3.TabStop = false;
            // 
            // pbImagen4
            // 
            pbImagen4.Image = Properties.Resources.ahorcado4;
            pbImagen4.Location = new Point(12, 81);
            pbImagen4.Name = "pbImagen4";
            pbImagen4.Size = new Size(453, 581);
            pbImagen4.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen4.TabIndex = 17;
            pbImagen4.TabStop = false;
            // 
            // pbImagen5
            // 
            pbImagen5.Image = Properties.Resources.ahorc3v;
            pbImagen5.Location = new Point(12, 81);
            pbImagen5.Name = "pbImagen5";
            pbImagen5.Size = new Size(453, 581);
            pbImagen5.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen5.TabIndex = 18;
            pbImagen5.TabStop = false;
            // 
            // pbImagen6
            // 
            pbImagen6.Image = Properties.Resources.ahorc2v;
            pbImagen6.Location = new Point(12, 81);
            pbImagen6.Name = "pbImagen6";
            pbImagen6.Size = new Size(453, 581);
            pbImagen6.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen6.TabIndex = 19;
            pbImagen6.TabStop = false;
            // 
            // pbImagen7
            // 
            pbImagen7.Image = Properties.Resources.ahorc1v;
            pbImagen7.Location = new Point(12, 81);
            pbImagen7.Name = "pbImagen7";
            pbImagen7.Size = new Size(453, 581);
            pbImagen7.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen7.TabIndex = 20;
            pbImagen7.TabStop = false;
            // 
            // pbImagen8
            // 
            pbImagen8.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            pbImagen8.Image = Properties.Resources.ahorc0vx;
            pbImagen8.Location = new Point(12, 81);
            pbImagen8.Name = "pbImagen8";
            pbImagen8.Size = new Size(453, 581);
            pbImagen8.SizeMode = PictureBoxSizeMode.StretchImage;
            pbImagen8.TabIndex = 21;
            pbImagen8.TabStop = false;
            // 
            // lbPuntuacionTexto
            // 
            lbPuntuacionTexto.AutoSize = true;
            lbPuntuacionTexto.BackColor = Color.Transparent;
            lbPuntuacionTexto.Font = new Font("Courier New", 22F, FontStyle.Bold, GraphicsUnit.Point);
            lbPuntuacionTexto.Location = new Point(3, 36);
            lbPuntuacionTexto.Name = "lbPuntuacionTexto";
            lbPuntuacionTexto.Size = new Size(260, 41);
            lbPuntuacionTexto.TabIndex = 22;
            lbPuntuacionTexto.Text = "Puntuación:";
            lbPuntuacionTexto.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // formJuego
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = SystemColors.Control;
            BackgroundImage = Properties.Resources.istockphoto_972936924_612x612;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1282, 673);
            Controls.Add(lbPuntuacionTexto);
            Controls.Add(pbImagen8);
            Controls.Add(pbImagen7);
            Controls.Add(pbImagen6);
            Controls.Add(pbImagen5);
            Controls.Add(pbImagen4);
            Controls.Add(pbImagen3);
            Controls.Add(pbImagen2);
            Controls.Add(pbImagen);
            Controls.Add(lbPuntos);
            Controls.Add(lbPalabraGuiones);
            Controls.Add(flBotonera);
            Controls.Add(lbTituloJuego);
            FormBorderStyle = FormBorderStyle.None;
            Name = "formJuego";
            Text = "Ahorcado";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pbImagen).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImagen8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public Label lbTituloJuego;
        public PictureBox pbPataIzqBaja;
        public FlowLayoutPanel flBotonera;
        public Label lbPalabraGuiones;
        public Label lbPuntos;
        public PictureBox pbImagen;
        public PictureBox pbImagen2;
        public PictureBox pbImagen3;
        public PictureBox pbImagen4;
        public PictureBox pbImagen5;
        public PictureBox pbImagen6;
        public PictureBox pbImagen7;
        public PictureBox pbImagen8;
        public Label lbPuntuacionTexto;
    }
}