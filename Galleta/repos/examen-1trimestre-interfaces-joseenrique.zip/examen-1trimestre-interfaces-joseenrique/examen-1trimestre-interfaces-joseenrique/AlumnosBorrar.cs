﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examen_1trimestre_interfaces_joseenrique
{
    public partial class formAlumnosBorrar : Form
    {
        public formAlumnosBorrar()
        {
            InitializeComponent();
        }

        private void btSalirAnadir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
