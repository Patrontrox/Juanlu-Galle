﻿namespace examen_1trimestre_interfaces_joseenrique
{
    partial class formAlumnosAnadir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbTituloDatos = new Label();
            lbCodigoAnadir = new Label();
            txtCodigoAnadir = new TextBox();
            txtNombreAnadir = new TextBox();
            lbNombreAnadir = new Label();
            txtApellidosAnadir = new TextBox();
            lbApellidosAnadir = new Label();
            txtTelefonoAnadir = new TextBox();
            lbTelefonoAnadir = new Label();
            txtDNIAnadir = new TextBox();
            lbDNIAnadir = new Label();
            txtLocalidadAnadir = new TextBox();
            lbLocalidadAnadir = new Label();
            txtNota1Anadir = new TextBox();
            lbNota1Anadir = new Label();
            lbTituloNotas = new Label();
            txtNota2Anadir = new TextBox();
            lbNota2Anadir = new Label();
            txtNota3Anadir = new TextBox();
            lbNota3Anadir = new Label();
            btAnadirAlumno = new Button();
            btSalirAnadir = new Button();
            SuspendLayout();
            // 
            // lbTituloDatos
            // 
            lbTituloDatos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbTituloDatos.AutoSize = true;
            lbTituloDatos.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            lbTituloDatos.Location = new Point(161, 33);
            lbTituloDatos.Name = "lbTituloDatos";
            lbTituloDatos.Size = new Size(112, 46);
            lbTituloDatos.TabIndex = 0;
            lbTituloDatos.Text = "Datos";
            // 
            // lbCodigoAnadir
            // 
            lbCodigoAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbCodigoAnadir.AutoSize = true;
            lbCodigoAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbCodigoAnadir.Location = new Point(34, 82);
            lbCodigoAnadir.Name = "lbCodigoAnadir";
            lbCodigoAnadir.Size = new Size(96, 35);
            lbCodigoAnadir.TabIndex = 1;
            lbCodigoAnadir.Text = "Codigo";
            // 
            // txtCodigoAnadir
            // 
            txtCodigoAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtCodigoAnadir.Location = new Point(161, 90);
            txtCodigoAnadir.Name = "txtCodigoAnadir";
            txtCodigoAnadir.Size = new Size(147, 27);
            txtCodigoAnadir.TabIndex = 2;
            // 
            // txtNombreAnadir
            // 
            txtNombreAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtNombreAnadir.Location = new Point(161, 145);
            txtNombreAnadir.Name = "txtNombreAnadir";
            txtNombreAnadir.Size = new Size(147, 27);
            txtNombreAnadir.TabIndex = 4;
            // 
            // lbNombreAnadir
            // 
            lbNombreAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbNombreAnadir.AutoSize = true;
            lbNombreAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbNombreAnadir.Location = new Point(34, 137);
            lbNombreAnadir.Name = "lbNombreAnadir";
            lbNombreAnadir.Size = new Size(108, 35);
            lbNombreAnadir.TabIndex = 3;
            lbNombreAnadir.Text = "Nombre";
            // 
            // txtApellidosAnadir
            // 
            txtApellidosAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtApellidosAnadir.Location = new Point(161, 197);
            txtApellidosAnadir.Name = "txtApellidosAnadir";
            txtApellidosAnadir.Size = new Size(147, 27);
            txtApellidosAnadir.TabIndex = 6;
            // 
            // lbApellidosAnadir
            // 
            lbApellidosAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbApellidosAnadir.AutoSize = true;
            lbApellidosAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbApellidosAnadir.Location = new Point(34, 189);
            lbApellidosAnadir.Name = "lbApellidosAnadir";
            lbApellidosAnadir.Size = new Size(118, 35);
            lbApellidosAnadir.TabIndex = 5;
            lbApellidosAnadir.Text = "Apellidos";
            // 
            // txtTelefonoAnadir
            // 
            txtTelefonoAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtTelefonoAnadir.Location = new Point(161, 242);
            txtTelefonoAnadir.Name = "txtTelefonoAnadir";
            txtTelefonoAnadir.Size = new Size(147, 27);
            txtTelefonoAnadir.TabIndex = 8;
            // 
            // lbTelefonoAnadir
            // 
            lbTelefonoAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbTelefonoAnadir.AutoSize = true;
            lbTelefonoAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbTelefonoAnadir.Location = new Point(34, 234);
            lbTelefonoAnadir.Name = "lbTelefonoAnadir";
            lbTelefonoAnadir.Size = new Size(110, 35);
            lbTelefonoAnadir.TabIndex = 7;
            lbTelefonoAnadir.Text = "Telefono";
            // 
            // txtDNIAnadir
            // 
            txtDNIAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtDNIAnadir.Location = new Point(161, 293);
            txtDNIAnadir.Name = "txtDNIAnadir";
            txtDNIAnadir.Size = new Size(147, 27);
            txtDNIAnadir.TabIndex = 10;
            // 
            // lbDNIAnadir
            // 
            lbDNIAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbDNIAnadir.AutoSize = true;
            lbDNIAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbDNIAnadir.Location = new Point(34, 285);
            lbDNIAnadir.Name = "lbDNIAnadir";
            lbDNIAnadir.Size = new Size(59, 35);
            lbDNIAnadir.TabIndex = 9;
            lbDNIAnadir.Text = "DNI";
            // 
            // txtLocalidadAnadir
            // 
            txtLocalidadAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtLocalidadAnadir.Location = new Point(161, 343);
            txtLocalidadAnadir.Name = "txtLocalidadAnadir";
            txtLocalidadAnadir.Size = new Size(147, 27);
            txtLocalidadAnadir.TabIndex = 12;
            // 
            // lbLocalidadAnadir
            // 
            lbLocalidadAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbLocalidadAnadir.AutoSize = true;
            lbLocalidadAnadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbLocalidadAnadir.Location = new Point(34, 335);
            lbLocalidadAnadir.Name = "lbLocalidadAnadir";
            lbLocalidadAnadir.Size = new Size(122, 35);
            lbLocalidadAnadir.TabIndex = 11;
            lbLocalidadAnadir.Text = "Localidad";
            // 
            // txtNota1Anadir
            // 
            txtNota1Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtNota1Anadir.Location = new Point(554, 90);
            txtNota1Anadir.Name = "txtNota1Anadir";
            txtNota1Anadir.Size = new Size(127, 27);
            txtNota1Anadir.TabIndex = 15;
            // 
            // lbNota1Anadir
            // 
            lbNota1Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbNota1Anadir.AutoSize = true;
            lbNota1Anadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbNota1Anadir.Location = new Point(325, 82);
            lbNota1Anadir.Name = "lbNota1Anadir";
            lbNota1Anadir.Size = new Size(210, 35);
            lbNota1Anadir.TabIndex = 14;
            lbNota1Anadir.Text = "Nota 1º Trimestre";
            // 
            // lbTituloNotas
            // 
            lbTituloNotas.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbTituloNotas.AutoSize = true;
            lbTituloNotas.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            lbTituloNotas.Location = new Point(547, 33);
            lbTituloNotas.Name = "lbTituloNotas";
            lbTituloNotas.Size = new Size(114, 46);
            lbTituloNotas.TabIndex = 13;
            lbTituloNotas.Text = "Notas";
            // 
            // txtNota2Anadir
            // 
            txtNota2Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtNota2Anadir.Location = new Point(554, 145);
            txtNota2Anadir.Name = "txtNota2Anadir";
            txtNota2Anadir.Size = new Size(127, 27);
            txtNota2Anadir.TabIndex = 17;
            // 
            // lbNota2Anadir
            // 
            lbNota2Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbNota2Anadir.AutoSize = true;
            lbNota2Anadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbNota2Anadir.Location = new Point(325, 137);
            lbNota2Anadir.Name = "lbNota2Anadir";
            lbNota2Anadir.Size = new Size(210, 35);
            lbNota2Anadir.TabIndex = 16;
            lbNota2Anadir.Text = "Nota 2º Trimestre";
            // 
            // txtNota3Anadir
            // 
            txtNota3Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtNota3Anadir.Location = new Point(554, 197);
            txtNota3Anadir.Name = "txtNota3Anadir";
            txtNota3Anadir.Size = new Size(127, 27);
            txtNota3Anadir.TabIndex = 19;
            // 
            // lbNota3Anadir
            // 
            lbNota3Anadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbNota3Anadir.AutoSize = true;
            lbNota3Anadir.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lbNota3Anadir.Location = new Point(325, 189);
            lbNota3Anadir.Name = "lbNota3Anadir";
            lbNota3Anadir.Size = new Size(210, 35);
            lbNota3Anadir.TabIndex = 18;
            lbNota3Anadir.Text = "Nota 3º Trimestre";
            // 
            // btAnadirAlumno
            // 
            btAnadirAlumno.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btAnadirAlumno.DialogResult = DialogResult.OK;
            btAnadirAlumno.FlatAppearance.MouseDownBackColor = Color.Lime;
            btAnadirAlumno.ForeColor = SystemColors.ActiveCaptionText;
            btAnadirAlumno.Location = new Point(302, 396);
            btAnadirAlumno.Name = "btAnadirAlumno";
            btAnadirAlumno.Size = new Size(157, 57);
            btAnadirAlumno.TabIndex = 22;
            btAnadirAlumno.Text = "Añadir Alumno";
            btAnadirAlumno.UseVisualStyleBackColor = true;
            btAnadirAlumno.Click += btAnadirAlumno_Click;
            // 
            // btSalirAnadir
            // 
            btSalirAnadir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btSalirAnadir.FlatAppearance.MouseDownBackColor = Color.Red;
            btSalirAnadir.Location = new Point(325, 459);
            btSalirAnadir.Name = "btSalirAnadir";
            btSalirAnadir.Size = new Size(116, 57);
            btSalirAnadir.TabIndex = 23;
            btSalirAnadir.Text = "Salir";
            btSalirAnadir.UseVisualStyleBackColor = true;
            btSalirAnadir.Click += btSalirAnadir_Click;
            // 
            // formAlumnosAnadir
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(728, 543);
            Controls.Add(btSalirAnadir);
            Controls.Add(btAnadirAlumno);
            Controls.Add(txtNota3Anadir);
            Controls.Add(lbNota3Anadir);
            Controls.Add(txtNota2Anadir);
            Controls.Add(lbNota2Anadir);
            Controls.Add(txtNota1Anadir);
            Controls.Add(lbNota1Anadir);
            Controls.Add(lbTituloNotas);
            Controls.Add(txtLocalidadAnadir);
            Controls.Add(lbLocalidadAnadir);
            Controls.Add(txtDNIAnadir);
            Controls.Add(lbDNIAnadir);
            Controls.Add(txtTelefonoAnadir);
            Controls.Add(lbTelefonoAnadir);
            Controls.Add(txtApellidosAnadir);
            Controls.Add(lbApellidosAnadir);
            Controls.Add(txtNombreAnadir);
            Controls.Add(lbNombreAnadir);
            Controls.Add(txtCodigoAnadir);
            Controls.Add(lbCodigoAnadir);
            Controls.Add(lbTituloDatos);
            Name = "formAlumnosAnadir";
            Text = "Añadir Alumno";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label lbTituloDatos;
        public Label lbCodigoAnadir;
        public TextBox txtCodigoAnadir;
        public TextBox txtNombreAnadir;
        public Label lbNombreAnadir;
        public TextBox txtApellidosAnadir;
        public Label lbApellidosAnadir;
        public TextBox txtTelefonoAnadir;
        public Label lbTelefonoAnadir;
        public TextBox txtDNIAnadir;
        public Label lbDNIAnadir;
        public TextBox txtLocalidadAnadir;
        public Label lbLocalidadAnadir;
        public TextBox txtNota1Anadir;
        public Label lbNota1Anadir;
        public Label lbTituloNotas;
        public TextBox txtNota2Anadir;
        public Label lbNota2Anadir;
        public TextBox txtNota3Anadir;
        public Label lbNota3Anadir;
        public Button btAnadirAlumno;
        public Button btSalirAnadir;
    }
}